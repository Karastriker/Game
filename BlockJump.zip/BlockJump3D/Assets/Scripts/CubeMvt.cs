using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CubeMvt : MonoBehaviour
{
    Rigidbody rb;
    public bool showClear;
    public GameObject ClearScreen;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        var mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        var mouseDir = mousePos - gameObject.transform.position;

        mouseDir = mouseDir.normalized;

        if (Input.GetMouseButtonDown(0))
        {
            this.GetComponent<Rigidbody>().velocity = Vector3.zero;

            Vector3 screenPoint = Camera.main.WorldToScreenPoint(transform.position);

            Vector3 direction = (Vector3)(Input.mousePosition - screenPoint);

            direction.Normalize();

            this.GetComponent<Rigidbody>().AddForce(direction * 10, ForceMode.Impulse);
        }
    }

    public void OnCollisionEnter(Collision col)
    {
        if(col.gameObject.tag == "RedWall")
        {
            GetComponent<Renderer>().material.color = Color.red;
        }
        else
        {

        }

        if (col.gameObject.tag == "BlueWall")
        {
            GetComponent<Renderer>().material.color = Color.blue;
        }
        else
        {

        }

        if (col.gameObject.tag == "Goal")
        {
            showClear = true;
            ClearScreen.SetActive(true);
            Application.Quit();
        }
        else
        {
            showClear = false;
            ClearScreen.SetActive(false);
        }
    }
}
