[System.Serializable]

public class Questions {
    public string question;
    public bool isTrue;
}
