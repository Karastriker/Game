[System.Serializable]
public class QnA
{
    public string[] Answers;
    public string Question;
    public int CorrectAnswer;
}
